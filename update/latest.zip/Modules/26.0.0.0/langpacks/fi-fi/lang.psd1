﻿ConvertFrom-StringData -StringData @'
	# fi-FI
	# Finnish (Finland)

	FontsUI                   = Segoe UI
	Mainname                  = Käyttöönottomoottori: lisää täysin automaattisesti Windows-järjestelmiin asennetut kielet
	Learn                     = Opiskella
	AddTo                     = Lisää
	Del                       = Poistaa
	Disable                   = Poista käytöstä
	Enable                    = Ota käyttöön
	Setting                   = Perustaa
	Done                      = Valmis
	OK                        = Varma
	Cancel                    = Peruuttaa
	AllSel                    = Valitse kaikki
	AllClear                  = Tyhjentää kaikki
	Refresh                   = Päivitä
	FileName                  = Tiedoston nimi
	SaveTo                    = Tallenna kohteeseen
	Operable                  = Toimiva
	Inoperable                = Käyttökelvoton
	Command                   = Komentorivi
	RuleName                  = Säännön nimi
	Language                  = Kieli
	AvailableLanguages        = Saatavilla olevat kielet
	SwitchLanguage            = Vaihtaa kieltä
	LanguageReset             = Palauta kieliasetukset
	LanguageCode              = Vyöhykemerkki
	LanguageSelRegion         = Valitse maasi tai alueesi
	LanguageRemember          = Muista valittu kieli
	LanguageSearchNo          = Saatavilla olevia kieliä ei löytynyt
	LanguageNoSel             = Valitse alue
	Search                    = Haku
	RefreshModules            = Päivitä kaikki moduulit kuumana
	PleaseChoose              = Ole hyvä ja valitse
	FailedCreateFolder        = Hakemiston luominen epäonnistui
	Failed                    = Epäonnistua
	ToMsg                     = {0} Palaa automaattisesti päävalikkoon sekunnin kuluttua.
	UserCancel                = Käyttäjä on peruuttanut toiminnon.
	Help                      = Auttaa
	WorkDone                  = Valmis, palaa pääliittymään painamalla mitä tahansa näppäintä...
	Short_Cmd                 = Pikanäppäimet
	Options                   = Vaihtoehdot
	LXPsWaitAssign            = Jaetaan
	Running                   = Juosta
	SpecialFunction           = PowerShell toiminnot
	WaitQueue                 = Odottaa jonossa
'@