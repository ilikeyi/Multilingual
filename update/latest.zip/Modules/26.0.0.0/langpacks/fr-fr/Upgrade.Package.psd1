﻿ConvertFrom-StringData -StringData @'
	# fr-FR
	# French (France)

	UpdateCreate              = Créer un package de mise à niveau
	UpdateLow                 = Exigences minimales: \
	UpCreateRear              = Que faire après la création
	UpCreateASC               = Ajouter la signature PGP au package de mise à niveau
	NoPGPKey                  = Il n'existe pas de clé privée utilisable dans PGP.
	CreateASCPwd              = Mot de passe du certificat
	CreateASCAuthor           = Signataire
	CreateASCAuthorTips       = Aucun signataire sélectionné.
	UpCreateSHA256            = Générez .SHA-256 pour le package de mise à niveau
	SelectFromError           = Erreur
	Uping                     = Générateur
	SkipCreate                = Sauter la génération, introuvable
	SoftIsInstl                 = {0} n'est pas installé.
	ShowPassword              = Afficher le mot de passe
'@