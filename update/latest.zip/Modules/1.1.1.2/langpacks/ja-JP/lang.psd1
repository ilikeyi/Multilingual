﻿ConvertFrom-StringData -StringData @'
	# ja-JP
	# Japanese (Japan)

	FontsUI                   = Yu Gothic UI
	Mainname                  = 展開エンジン: Windows システムにインストールされている言語を完全に自動的に追加します
	Learn                     = 勉強
	AddTo                     = 追加
	Disable                   = 無効にする
	Enabled                   = 有効
	Done                      = 実施する
	OK                        = 決定する
	Cancel                    = キャンセル
	AllSel                    = すべて選択
	AllClear                  = すべてクリア
	FileName                  = ファイル名
	SaveTo                    = に保存
	Operable                  = 操作可能
	Inoperable                = 動作不能
	AvailableLanguages        = 使用可能な言語
	SwitchLanguage            = 言語を切り替える
	LanguageReset             = 言語設定をリセットする
	LanguageCode              = ゾーンマーカー
	RefreshModules            = すべてのモジュールをホットリフレッシュします
	PleaseChoose              = 選んでください
	PleaseChooseMain          = 바로가기 또는 옵션
	FailedCreateFolder        = ディレクトリの作成に失敗しました:
	Failed                    = 失敗
	ToMsg                     = \n   {0} 数秒後、自動的にメインメニューに戻ります。
	ToQuit                    = \n   {0} 数秒でメイン メニューを終了します。
	UserCancel                = ユーザーが操作をキャンセルしました。
	Help                      = ヘルプ
	WorkDone                  = 完了し, メインインターフェイスに戻って任意のキーを押します...
	Short_Cmd                 = ショートカットコマンド
'@