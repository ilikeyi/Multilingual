﻿ConvertFrom-StringData -StringData @'
	# fi-FI
	# Finnish (Finland)

	UpdateCreate              = Luo päivityspaketti
	UpdateLow                 = Vähimmäisvaatimukset: \
	UpCreateRear              = Mitä tehdä luomisen jälkeen
	UpCreateASC               = Lisää PGP-allekirjoitus päivityspakettiin
	NoPGPKey                  = PGP: ssä ei ole käyttökelpoista yksityistä avainta.
	CreateASCPwd              = Sertifikaatin salasana
	CreateASCAuthor           = Allekirjoittaja
	CreateASCAuthorTips       = Allekirjoittajia ei ole valittu.
	UpCreateSHA256            = Luo .SHA-256 päivityspakettia varten
	SelectFromError           = Virhe
	Uping                     = Luodaan
	SkipCreate                = Ohita sukupolvi, ei löydy
	SoftIsInstl                 = {0} ei ole asennettu.
	ShowPassword              = Näytä salasana
'@