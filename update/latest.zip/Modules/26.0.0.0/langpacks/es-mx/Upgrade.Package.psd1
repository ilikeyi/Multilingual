﻿ConvertFrom-StringData -StringData @'
	# es-MX
	# Spanish (Mexico)

	UpdateCreate              = Crear paquete de actualización
	UpdateLow                 = Requisitos mínimos: \
	UpCreateRear              = Qué hacer después de crear
	UpCreateASC               = Agregue la firma PGP al paquete de actualización
	NoPGPKey                  = No hay ninguna clave privada utilizable en PGP.
	CreateASCPwd              = Contraseña del certificado
	CreateASCAuthor           = Firmante
	CreateASCAuthorTips       = No se seleccionaron firmantes.
	UpCreateSHA256            = Genere .SHA-256 para el paquete de actualización
	SelectFromError           = Error
	Uping                     = Generando
	SkipCreate                = Saltar generación, no encontrado
	SoftIsInstl                 = {0} no está instalado.
	ShowPassword              = Mostrar contraseña
'@