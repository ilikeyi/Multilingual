﻿ConvertFrom-StringData -StringData @'
	# zh-CN
	# Chinese (Simplified, China)

	UpdateCreate              = 创建升级包
	UpdateLow                 = 最低要求: \
	UpCreateRear              = 创建后需要做些什么
	UpCreateASC               = 给升级包添加 PGP 签名
	NoPGPKey                  = PGP 里没有可用的私钥
	CreateASCPwd              = 证书密码
	CreateASCAuthor           = 签署者
	CreateASCAuthorTips       = 未选择签署者.
	UpCreateSHA256            = 给升级包生成 .SHA-256
	SelectFromError           = 错误
	Uping                     = 正在生成
	SkipCreate                = 跳过生成, 未找到
	SoftIsInstl                 = 未安装 {0}.
	ShowPassword              = 显示密码
'@