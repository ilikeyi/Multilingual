﻿ConvertFrom-StringData -StringData @'
	SettingLangAndKeyboard    = システム言語とキーボードを設定する
	SettingUTF8               = Beta バージョン：使用 Unicode UTF-8 利用可能なグローバル言語サポート
	SettingUTF8Tips           = 使用後に新たな問題が発生する場合があります。
	SettingLocale             = システムロケールを設定する
	SettingLocaleTips         = 展開ゾーンタグが存在しない場合に有効です。
	FirstExperience           = 初体験
	DiskSearch                = 検索プラン：
	DiskSearchFind            = 検索、実行中：{0}
	DeployCleanup             = Deploy ディレクトリをクリーンアップします
	FirstDeployment           = 初めての導入
	FirstDeploymentPopup      = メインインターフェイスをポップアップします
	FirstExpFinishOnDemand    = 計画どおり、最初の事前体験を許可する
	DeployTask                = 展開タスク：
	Reboot                    = コンピューターを再起動します
	NetworkLocationWizard     = ネットワーク ロケーション ウィザード
	LangMul                   = 多言語
	LangSingle                = 単一言語
	RandomlyWaitSel           = ランダムに選択された言語を待ちます
	RandomlySelResults        = 結果をランダムに選択します
	LanguageInstalled         = 言語パックがシステムにインストールされています
	SetLang                   = システムの優先言語を設定します：
	SetTimezone               = タイムゾーンの 設定：
	KeyboardSequence          = キーボード シーケンス:
	Wubi                      = ウビ
	Pinyi                     = ピンイン
'@