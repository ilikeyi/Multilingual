﻿ConvertFrom-StringData -StringData @'
	# de-DE
	# German (Germany)

	ChkUpdate                 = Suchen Sie nach Updates
	UpdateServerSelect        = Automatische Serverauswahl oder benutzerdefinierte Auswahl
	UpdateServerNoSelect      = Bitte wählen Sie einen verfügbaren Server aus
	UpdateSilent              = Aktualisieren Sie im Hintergrund, wenn Updates verfügbar sind
	UpdateClean               = Lassen Sie die Reinigung alter Versionen in Ruhe zu
	UpdateReset               = Setzen Sie diese Lösung zurück
	UpdateResetTips           = Wenn die Download-Adresse verfügbar ist, wird der Download erzwungen und automatisch aktualisiert.
	UpdateCheckServerStatus   = Serverstatus prüfen ( {0} Optionen verfügbar )
	UpdateServerAddress       = Serveradresse
	UpdatePriority            = Bereits als Priorität festgelegt
	UpdateServerTestFailed    = Serverstatustest fehlgeschlagen
	UpdateQueryingUpdate      = Ich frage nach Updates...
	UpdateQueryingTime        = Die Überprüfung, ob die neueste Version verfügbar ist, hat {0} Millisekunden gedauert.
	UpdateConnectFailed       = Es konnte keine Verbindung zum Remote-Server hergestellt werden, die Suche nach Updates wurde abgebrochen.
	UpdateREConnect           = Verbindung fehlgeschlagen, erneuter Versuch zum {0}/{1} Mal.
	UpdateMinimumVersion      = Erfüllt die Mindestanforderungen an die Updater-Version, erforderliche Mindestversion: {0}
	UpdateVerifyAvailable     = Überprüfen Sie, ob die Adresse verfügbar ist
	UpdateDownloadAddress     = Adresse herunterladen
	UpdateAvailable           = Verfügbar
	UpdateUnavailable         = Nicht verfügbar
	UpdateCurrent             = Aktuelle Version
	UpdateLatest              = Neueste verfügbare Version
	UpdateNewLatest           = Entdecken Sie neue verfügbare Versionen!
	UpdateSkipUpdateCheck     = Vorkonfigurierte Richtlinie, die die erstmalige Ausführung automatischer Updates verhindert.
	UpdateTimeUsed            = Zeitaufwand
	UpdatePostProc            = Nachbearbeitung
	UpdateNotExecuted         = Nicht ausgeführt
	UpdateNoPost              = Nachbearbeitungsaufgabe nicht gefunden
	UpdateUnpacking           = Entpacken
	UpdateDone                = Erfolgreich aktualisiert!
	UpdateDoneRefresh         = Nach Abschluss der Aktualisierung wird die Funktionsverarbeitung durchgeführt.
	UpdateUpdateStop          = Beim Herunterladen des Updates ist ein Fehler aufgetreten und der Update-Vorgang wurde abgebrochen.
	UpdateInstall             = Möchten Sie dieses Update installieren?
	UpdateInstallSel          = Ja, das obige Update wird installiert.\nNein, das Update wird nicht installiert
	UpdateNotSatisfied        = \n  lt nicht die Mindestanforderungen für die Update Programmversion,\n\n  Erforderliche Mindestversion: {0}\n\n  Bitte laden Sie die Datei erneut herunter.\n\n  Die Suche nach Updates wurde abgebrochen.\n
	IsAllowSHA256Check        = SHA256-Hash-Verifizierung zulassen
	GetSHAFailed              = Hash konnte nicht zum Vergleich mit der heruntergeladenen Datei abgerufen werden.
	Verify_Done               = Verifizierung erfolgreich.
	Verify_Failed             = Verifizierung fehlgeschlagen, Hash stimmt nicht überein.
	Auto_Update_Allow         = Automatische Hintergrundprüfung auf Updates zulassen
	Auto_Update_New_Allow     = Automatische Updates zulassen, sobald neue Updates erkannt werden.
	Auto_Check_Time           = Stunden, Intervall zwischen automatischen Prüfungen
	Auto_Last_Check_Time      = Zeitpunkt der letzten automatischen Updateprüfung
	Auto_Next_Check_Time      = Nächste Prüfung in maximal {0} Stunden
	Auto_First_Check          = Keine Updateprüfung durchgeführt, erste Updateprüfung wird durchgeführt
	Auto_Update_Last_status   = Status der letzten Aktualisierung
	Auto_Update_IsLatest      = Sa ikoya na kena itukutuku vou duadua.
'@