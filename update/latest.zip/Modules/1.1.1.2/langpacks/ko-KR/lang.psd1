﻿ConvertFrom-StringData -StringData @'
	# ko-KR
	# Korean (Korea)

	FontsUI                   = Malgun Gothic
	Mainname                  = 배포 엔진: Windows 시스템에 설치된 언어를 완전 자동으로 추가합니다
	Learn                     = 공부하다
	AddTo                     = 에 추가
	Del                       = 삭제
	Disable                   = 비활성화
	Enabled                   = 할 수있게하다
	Done                      = 수행하다
	OK                        = 결정
	Cancel                    = 취소
	AllSel                    = 모두 선택
	AllClear                  = 모두 지우기
	FileName                  = 파일
	SaveTo                    = 저장 대상
	Operable                  = 실시 가능한
	Inoperable                = 작동 불가
	AvailableLanguages        = 사용 가능한 언어입니다
	SwitchLanguage            = 언어 전환
	LanguageReset             = 언어 설정 재설정
	LanguageCode              = 구역 마커
	RefreshModules            = 모든 모듈을 핫 리프레시
	PleaseChoose              = 선택하세요
	PleaseChooseMain          = 바로가기 또는 옵션
	FailedCreateFolder        = 디렉터리 생성 실패
	Failed                    = 실패했습니다
	ToMsg                     = \n   {0} 몇 초 후 자동으로 주 메뉴로 돌아갑니다.
	ToQuit                    = \n   {0} 몇 초 안에 메인 메뉴를 종료합니다.
	UserCancel                = 사용자가 작업을 취소했습니다.
	Help                      = 돕다
	WorkDone                  = 완료, 기본 인터페이스로 돌아가려면 아무 키나 누르십시오...
	Short_Cmd                 = 바로 가기 명령
'@