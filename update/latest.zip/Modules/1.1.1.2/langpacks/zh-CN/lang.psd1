﻿ConvertFrom-StringData -StringData @'
	# zh-CN
	# Chinese (Simplified, China)

	FontsUI                   = Microsoft YaHei UI
	Mainname                  = 部署引擎：全自动添加 Windows 系统已安装的语言
	Learn                     = 学习
	AddTo                     = 添加
	Disable                   = 禁用
	Enabled                   = 启用
	Done                      = 完成
	OK                        = 确定
	Cancel                    = 取消
	AllSel                    = 选择所有
	AllClear                  = 清除所有
	FileName                  = 文件名
	SaveTo                    = 保存到
	Operable                  = 可操作
	Inoperable                = 不可操作
	AvailableLanguages        = 可用语言
	SwitchLanguage            = 切换语言
	LanguageReset             = 重置语言设置
	LanguageCode              = 区域标记
	RefreshModules            = 热刷新所有模块
	PleaseChoose              = 请选择
	PleaseChooseMain          = 快捷指令或选择
	FailedCreateFolder        = 创建目录失败：
	Failed                    = 失败
	ToMsg                     = \n   {0} 秒后自动返回到主菜单。
	ToQuit                    = \n   {0} 秒后退出主菜单。
	UserCancel                = 用户已取消操作。
	Help                      = 帮助
	WorkDone                  = 完成，按任意键返回主界面...
	Short_Cmd                 = 快捷指令
'@